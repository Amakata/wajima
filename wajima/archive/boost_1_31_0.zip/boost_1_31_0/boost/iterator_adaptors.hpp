// Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

#ifndef BOOST_ITERATOR_ADAPTOR_13062003HK_HPP
#define BOOST_ITERATOR_ADAPTOR_13062003HK_HPP

#define BOOST_ITERATOR_ADAPTORS_VERSION 0x0200
#include <boost/iterator/iterator_adaptor.hpp>

#endif // BOOST_ITERATOR_ADAPTOR_13062003HK_HPP
