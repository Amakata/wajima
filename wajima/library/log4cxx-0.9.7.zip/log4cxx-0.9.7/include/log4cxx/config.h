#ifndef _LOG4CXX_CONFIG_H
#define _LOG4CXX_CONFIG_H

#ifdef _MSC_VER
#include <log4cxx/config_msvc.h>
#else
#include <log4cxx/config_auto.h>
#endif

#endif //_LOG4CXX_CONFIG_H
