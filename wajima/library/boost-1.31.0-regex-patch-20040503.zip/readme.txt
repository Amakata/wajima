These patches address issues discovered in the Boost.Regex library after the release of Boost-1.31.0.

To install just copy these files into boost-path/boost/regex/v4 and then
rebuild (and reinstall) the regex library.

John Maddock
03 May 2004.
